package App;


import Controller.TelaController;
import View.InicioM;
import View.ListaM;
import View.CadastroM;
import java.util.ArrayList;
import javax.swing.JFrame;

public class App {
    
    public static void main(String[] args) {
        InicioM inicio = new InicioM();
        ListaM lista = new ListaM();
        CadastroM cadastro = new CadastroM();
        
        TelaController tc = new TelaController(inicio, lista, cadastro);
        tc.initController();
        inicio.setVisible(true);
        lista.setVisible(false);
        cadastro.setVisible(false);
    }
}
