package Controller;

import Model.Macro;
import Model.MacroDAO;
import View.CadastroM;
import View.ListaM;
import View.InicioM;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MacroController {

    private ListaM lista;
    private MacroDAO dao = new MacroDAO();
    private CadastroM cadastro;
    private InicioM inicio;

    public MacroController(ListaM lista, CadastroM cadastro, InicioM inicio) {
        this.lista = lista;
        this.cadastro = cadastro;
        this.inicio = inicio;
    }

    public void initController() {
        
    }

}