package Controller;

import View.InicioM;
import View.ListaM;
import View.CadastroM;

public class TelaController {
    private InicioM inicio;
    private ListaM lista;
    private CadastroM cadastro;
    

    public TelaController(InicioM inicio, ListaM lista, CadastroM cadastro) {
        this.inicio = inicio;
        this.lista = lista;
        this.cadastro = cadastro;
    }
    
    public void initController(){
        //mudar da tela listar para inicio
        lista.getjBVoltar().addActionListener(e -> exibirTelaInicio());
        //mudar da tela de cadastro para tela listagem
        inicio.getjBListar().addActionListener(e -> exibirTelaLista());
        cadastro.getjBVoltarCadIni().addActionListener(e -> exibirTelaInicio());
        inicio.getjBNovo().addActionListener(e -> exibirTelaCadastro());
    }
    
    private void exibirTelaInicio(){
        inicio.setVisible(true);
        lista.setVisible(false);
        cadastro.setVisible(false);
    }
    
    private void exibirTelaLista(){
        lista.setVisible(true);
        inicio.setVisible(false);
    }
    
    private void exibirTelaCadastro(){
        cadastro.setVisible(true);
        inicio.setVisible(false);
    }
}
