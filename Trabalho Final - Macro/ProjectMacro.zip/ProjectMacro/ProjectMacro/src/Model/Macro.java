package Model;

public class Macro {
    private int id;
    private String tecla;
    private String acao;
    
    public Macro(int id, String tecla, String acao) {
        this.id = id;
        this.tecla = tecla;
        this.acao = acao;
       
    }

    public Macro(String tecla, String acao) {
        this.tecla = tecla;
        this.acao = acao;

    }

    public int getId() {
        return id;
    }

    public String getTecla() {
        return tecla;
    }

    public String getAcao() {
        return acao;
    }

    @Override
    public String toString() {
        return "\nID:" + id + "\nTecla: " + tecla + "\nAção:" + acao;
    }
}
