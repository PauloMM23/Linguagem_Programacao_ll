package Model;

import ConnectionFactory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MacroDAO {

    private Connection con;

    public int inserirFuncionario(Macro macro) {
        //Criando aquery de inserção
        String insert = "Insert into Macro(Tecla,Acao) "
                + "values (?, ?);";

        PreparedStatement pst = null;
        //Abrir a conexão
        //con = new ConnectionFactory().getConnection();
        try {
            con = new ConnectionFactory().getConnection();
            //Preparar a query para execução
            pst = con.prepareStatement(insert);
            //Setando o valores a serem inseridos
            pst.setString(1, macro.getTecla());
            pst.setString(2, macro.getAcao());
            
            //Executando a query
            pst.execute();
            //Fechando a conexão
            con.close();
            pst.close();
            return 1;
        } catch (SQLException e) {
            System.out.println("ERRO AO INSERIR REGISTRO: " + e);
            System.out.println(e.getErrorCode());
            return e.getErrorCode();
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException ex) {
                Logger.getLogger(MacroDAO.class.getName()).log(Level.SEVERE, null, ex);
                return ex.getErrorCode();
            }

        }

    }
}
