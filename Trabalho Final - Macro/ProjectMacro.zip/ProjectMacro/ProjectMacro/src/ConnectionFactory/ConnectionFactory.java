package ConnectionFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    private Connection con;
    private final String url = "jdbc:mysql://localhost:3306/projectmacro";
    private final String user = "root";
    private final String password = "Pauloandre";

    //método que retorna uma conexão
    public Connection getConnection() throws SQLException {
         con = DriverManager.getConnection(url, user, password);
            return con;
    }
}
